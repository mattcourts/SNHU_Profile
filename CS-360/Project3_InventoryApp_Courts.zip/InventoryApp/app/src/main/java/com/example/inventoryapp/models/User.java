package com.example.inventoryapp.models;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "user")
public class User {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name= "id")
    private int uid;

    @NonNull
    @ColumnInfo(name = "username")
    private String userName;

    @NonNull
    @ColumnInfo(name = "passkey")
    private String passkey;

    @NonNull
    @ColumnInfo(name = "phone")
    private String phone;

    @NonNull
    @ColumnInfo(name = "notification")
    private boolean notification;

    public User( @NonNull String userName, @NonNull String passkey){
        this.userName = userName;
        this.passkey = passkey;
        this.notification = false;
        this.phone = "";
    }

    public int getUid() {
        return uid;
    }

    @NonNull
    public String getPasskey() {
        return passkey;
    }

    @NonNull
    public String getPhone() {
        return phone;
    }

    @NonNull
    public String getUserName() {
        return userName;
    }

    public void setPasskey(@NonNull String passkey) {
        this.passkey = passkey;
    }

    public void setPhone(@NonNull String phone) {
        this.phone = phone;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public void setUserName(@NonNull String userName) {
        this.userName = userName;
    }

    public void setNotification(boolean notification) {
        this.notification = notification;
    }

    public boolean isNotification() {
        return notification;
    }
}
