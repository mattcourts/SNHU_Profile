package com.example.inventoryapp.repository;

import android.content.Context;

import com.example.inventoryapp.dao.UserDao;
import com.example.inventoryapp.database.AppDatabase;
import com.example.inventoryapp.models.User;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UserRepository {
    private final UserDao userDao;
    private final ExecutorService executorService;

    public UserRepository(Context context){
        AppDatabase db = AppDatabase.getDatabase(context);
        userDao = db.userDao();
        executorService = Executors.newSingleThreadExecutor();
    }

    public void addUser(User user){
        executorService.execute(()->userDao.addUser(user));
    }

    public User getUser(String userName){
        return userDao.getUserByUserName(userName);
    }

    public void setNotification(String userName, boolean notification){
        userDao.updateNotification(userName,notification);
    }

    public void updatePhone(String userName, String phone){
        userDao.updatePhone(userName,phone);
    }
}
