package com.example.inventoryapp.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.inventoryapp.models.Product;

import java.util.List;

@Dao
public interface ProductDao {

    @Insert
    void InsertProduct(Product product);

    @Query("SELECT * FROM product ORDER BY name ASC")
    LiveData<List<Product>> getAllProducts();

    @Query("SELECT * FROM product WHERE name = :name LIMIT 1")
    Product getProductByName(String name);

    @Query("SELECT * FROM product WHERE id = :ID LIMIT 1")
    Product getProductByID(String ID);

    @Update
    void updateProduct(Product product);

    @Delete
    void deleteProduct(Product product);
}




