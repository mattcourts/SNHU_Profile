package com.example.inventoryapp.repository;

import android.content.Context;

import androidx.lifecycle.LiveData;

import com.example.inventoryapp.dao.ProductDao;
import com.example.inventoryapp.database.AppDatabase;
import com.example.inventoryapp.models.Product;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProductRepository {

    private final ProductDao productDao;
    private final LiveData<List<Product>> productList;
    private final ExecutorService executorService;

    public ProductRepository(Context context){
        AppDatabase db = AppDatabase.getDatabase(context);
        productDao = db.productDao();
        productList = productDao.getAllProducts();
        executorService = Executors.newSingleThreadExecutor();
    }

    public Product getByName(String name){
        return productDao.getProductByName(name);
    }

    public Product getByID(String id){
        return productDao.getProductByID(id);
    }

    public LiveData<List<Product>> getProductList() {
        return productList;
    }

    public void Add(Product product){
        executorService.execute(()-> productDao.InsertProduct(product));
    }

    public void update(Product product){
        executorService.execute(()-> productDao.updateProduct(product));
    }

    public void delete(Product product){
        executorService.execute(()-> productDao.deleteProduct(product));
    }


}
