package com.example.inventoryapp.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.inventoryapp.models.User;

@Dao
public interface UserDao {

    //CRUD interface for user model
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addUser(User uSer);

    @Query("SELECT * FROM user WHERE username = :userName LIMIT 1")
    User getUserByUserName(String userName);

    @Query("UPDATE user SET notification = :b WHERE username = :userName")
    void updateNotification(String userName, boolean b);

    @Query("UPDATE user SET phone = :phoneNumber WHERE username = :userName")
    void updatePhone(String userName, String phoneNumber);

    @Update
    void updateUser(User user);

    @Delete
    void deleteUser(User user);
}
