package com.example.inventoryapp.view;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inventoryapp.R;
import com.example.inventoryapp.adapter.ProductAdapter;
import com.example.inventoryapp.models.Product;
import com.example.inventoryapp.models.User;
import com.example.inventoryapp.viewModel.ProductViewModel;
import com.example.inventoryapp.viewModel.UserViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.w3c.dom.Text;

import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private static final int REQUEST_SEND_SMS = 1;

    private ProductViewModel productViewModel;
    private ProductAdapter productAdapter;
    private UserViewModel userViewModel;
    private SwitchCompat switchCompat;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        productViewModel = new ViewModelProvider(this).get(ProductViewModel.class);
        userViewModel = new ViewModelProvider(this).get(UserViewModel.class);

        //get active user for sms
        Intent intent = getIntent();
        username = intent.getStringExtra("username");

        //configure and set up recycler view
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        productAdapter = new ProductAdapter(this,this::showProductActivity);
        recyclerView.setAdapter(productAdapter);

        // configure floating action button
        FloatingActionButton floatingActionButton = findViewById(R.id.AddNewButton);
        floatingActionButton.setOnClickListener(v -> {
            showNewProductActivity();
        });

        // set up observer for products
        productViewModel.getAllProducts().observe(this, products -> productAdapter.setProducts(products));

        //check for phone
        promptForPhoneNumber(username);

    }

    private void showNewProductActivity() {
        // using a dialog need to grab the layout and set it up
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.new_activity_item, null);
        builder.setView(dialogView);

        // get all textviews
        TextView productID = dialogView.findViewById(R.id.item_id_field);
        TextView productName = dialogView.findViewById(R.id.item_name_field);
        TextView productCount = dialogView.findViewById(R.id.item_count_field);

        // prepare buttons for listeners
        Button saveButton = dialogView.findViewById(R.id.new_item_button_submit);
        Button cancelButton = dialogView.findViewById(R.id.new_item_button_cancel);


        // render dialog to set up save and cancel buttons
        AlertDialog dialog = builder.create();

        // cancel button listener
        cancelButton.setOnClickListener(v -> dialog.dismiss());

        // save button listener
        saveButton.setOnClickListener(v -> {
            if (String.valueOf(productID.getText()).isEmpty() ||
                    String.valueOf(productName.getText()).isEmpty() ||
                    String.valueOf(productCount.getText()).isEmpty()){
                Toast.makeText(this,"Cannot save, please fill out all fields", Toast.LENGTH_LONG);
                return;
            }
            Product product = new Product(String.valueOf(productID.getText()),String.valueOf(productName.getText()),Integer.parseInt( String.valueOf(productCount.getText())));
            productViewModel.add(product);
            dialog.dismiss();
        });

        dialog.show();
    }

    private void showProductActivity(Product product) {
        // using a dialog need to grab the layout and set it up
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.activity_item, null);
        builder.setView(dialogView);

        // get all textviews
        TextView productID = dialogView.findViewById(R.id.item_id_field);
        TextView productName = dialogView.findViewById(R.id.item_name_field);
        TextView productCount = dialogView.findViewById(R.id.item_count_field);

        // update text fields
        productID.setText(product.getId());
        productName.setText(product.getName());
        productCount.setText(String.valueOf(product.getQuantity()));

        // prepare buttons for listeners
        Button incrementButton = dialogView.findViewById(R.id.item_button_increment);
        Button decrementButton = dialogView.findViewById(R.id.item_button_decrement);
        Button deleteButton = dialogView.findViewById(R.id.item_button_delete);
        Button saveButton = dialogView.findViewById(R.id.item_button_submit);
        Button cancelButton = dialogView.findViewById(R.id.item_button_cancel);

        deleteButton.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setMessage("Confirm deletion!")
                    .setTitle("Delete Item")
                    .setPositiveButton("Delete Forever", (dialog, which)->{
                        productViewModel.delete(product);
                        dialog.dismiss();
                        cancelButton.performClick();
                    })
                    .setNegativeButton("Cancel",(dialog, which)-> dialog.dismiss())
                    .show();
        });

        //increment button listener, increasing count by one
        incrementButton.setOnClickListener(v -> {
            product.setQuantity(product.getQuantity() + 1);
            productCount.setText(String.valueOf(product.getQuantity()));
        });

        //decrement button listener, decreasing quantity by one
        decrementButton.setOnClickListener(v -> {
            product.setQuantity(product.getQuantity() - 1);
            productCount.setText(String.valueOf(product.getQuantity()));
        });

        // render dialog to set up save and cancel buttons
        AlertDialog dialog = builder.create();

        // cancel button listener
        cancelButton.setOnClickListener(v -> dialog.dismiss());

        // save button listener
        saveButton.setOnClickListener(v -> {
            productViewModel.update(product);
            if (product.getQuantity() <= 0){
                sendSmsNotification(product);
            }
            dialog.dismiss();
        });

        dialog.show();
    }


    // get and populate phone number
    private void promptForPhoneNumber(String username) {
        //exit if user has phone
        if (!userViewModel.getUser(username).getPhone().isEmpty()) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_phone, null);
        builder.setView(dialogView);

        final EditText input = dialogView.findViewById(R.id.phone_number_input);

        // Handle user clicking OK button
        builder.setPositiveButton("OK", (dialog, which) -> {
            String phoneNumber = input.getText().toString();
            // Check if phone number is valid.
            if (isValidPhoneNumber(phoneNumber)) {
                userViewModel.updatePhone(username,phoneNumber);
                Toast.makeText(this, "Phone number added!", Toast.LENGTH_SHORT).show();

                // Once number has been added, check SMS permission
                checkAndRequestSmsPermission();
            } else {
                // User entered an invalid number
                Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
            }
        });

        // Cancel button
        builder.setNegativeButton("Cancel", (dialog, which) -> {
            dialog.cancel();
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber.length() >= 10 && PhoneNumberUtils.isGlobalPhoneNumber(phoneNumber);
    }

    private void checkAndRequestSmsPermission() {
        // check for permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // has been previously denied
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                // show if denied
                new AlertDialog.Builder(this)
                        .setTitle("SMS Permission Needed")
                        .setMessage("This app requires SMS permission to send notifications. Please allow SMS permission.")
                        .setPositiveButton("OK", (dialog, which) ->
                                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SEND_SMS))
                        .setNegativeButton("Cancel", (dialog, which) -> {
                            dialog.dismiss();
                        })
                        .create()
                        .show();
            } else {
                // Request permission
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SEND_SMS);
            }
        } else {
            // SMS permission has already been granted
            userViewModel.setNotification(username, true);
            Toast.makeText(this, "SMS notifications enabled", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_SEND_SMS) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                // User granted SMS permission, update database and make a toast
                userViewModel.setNotification(username, true);
                Toast.makeText(this, "SMS notifications enabled", Toast.LENGTH_SHORT).show();
            } else {
                // User denied SMS permission, uncheck switch and make a toast
                userViewModel.setNotification(username, false);
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Method for sending SMS notifications
    private void sendSmsNotification(Product product) {

        // get user and check if user has given permission;
        User user = userViewModel.getUser(username);
        if (user.isNotification()) {

            String message = "Item Inventory Low for " + product.getName();

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(user.getPhone(), null, message, null, null);

        } else {
            // alert user notifications are off
            Toast.makeText(this, "Item quantity at or below 0, notifications are currently disabled.", Toast.LENGTH_SHORT).show();
        }
    }
}
