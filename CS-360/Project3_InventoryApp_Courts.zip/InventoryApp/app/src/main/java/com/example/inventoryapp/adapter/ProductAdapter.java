package com.example.inventoryapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inventoryapp.R;
import com.example.inventoryapp.models.Product;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {

    private final LayoutInflater layoutInflater;
    private List<Product> productList;
    private final OnItemClickListener onItemClickListener;

    public interface OnItemClickListener{
        void onItemClick(Product product);
    }

    public ProductAdapter(Context context, OnItemClickListener listener){
        layoutInflater = LayoutInflater.from(context);
        this.onItemClickListener = listener;
    }

    @NonNull
    @Override
    public ProductAdapter.ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View productView = layoutInflater.inflate(R.layout.activity_inventory_recycler_item, parent, false);
        return new ProductViewHolder(productView);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        if (productList != null){
            Product product = productList.get(position);
            holder.bind(product, onItemClickListener);
        }
    }

    @Override
    public int getItemCount() {
        if (productList != null) {
            return productList.size();
        } else return 0;
    }

    public void setProducts(List<Product> products){
        productList = products;
        notifyDataSetChanged();
    }



    public static class ProductViewHolder extends RecyclerView.ViewHolder {

        private final TextView tvItemId;
        private final TextView tvItemName;
        private final TextView tvItemCount;
        private final Button deleteButton;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            tvItemId = itemView.findViewById(R.id.recycler_id);
            tvItemName = itemView.findViewById(R.id.recycler_name);
            tvItemCount = itemView.findViewById(R.id.recycler_count);
            deleteButton = itemView.findViewById(R.id.recycler_delete);
        }

        public void bind(Product product, OnItemClickListener listener){
            tvItemId.setText(product.getId());
            tvItemName.setText(product.getName());
            tvItemCount.setText(String.valueOf(product.getQuantity()));

            deleteButton.setOnClickListener(v-> {
                listener.onItemClick(product);
            });
        }
    }

}
