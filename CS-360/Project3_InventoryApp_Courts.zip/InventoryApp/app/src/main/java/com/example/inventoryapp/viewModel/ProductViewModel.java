package com.example.inventoryapp.viewModel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.inventoryapp.models.Product;
import com.example.inventoryapp.repository.ProductRepository;

import java.util.List;

public class ProductViewModel extends AndroidViewModel {

    private final ProductRepository productRepository;

    public ProductViewModel(@NonNull Application application) {
        super(application);
        productRepository = new ProductRepository(application);
    }

    public void add(Product product){
        productRepository.Add(product);
    }

    public Product getByName(String name){
        return productRepository.getByName(name);
    }

    public Product getByID(String id){
        return productRepository.getByID(id);
    }

    public LiveData<List<Product>> getAllProducts(){
        return productRepository.getProductList();
    }

    public void update(Product product){ productRepository.update(product);}

    public void delete(Product product){
        productRepository.delete(product);
    }


}
