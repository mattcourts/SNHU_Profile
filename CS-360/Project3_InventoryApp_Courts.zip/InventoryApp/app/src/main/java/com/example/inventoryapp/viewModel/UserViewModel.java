package com.example.inventoryapp.viewModel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

import com.example.inventoryapp.models.User;
import com.example.inventoryapp.repository.UserRepository;

public class UserViewModel extends AndroidViewModel {

    private final UserRepository userRepository;

    public UserViewModel(@NonNull Application application) {
        super(application);
        userRepository = new UserRepository(application);
    }

    public void addUser(User user){
        userRepository.addUser(user);
    }

    public User getUser(String userName){
       return userRepository.getUser(userName);
    }

    public void setNotification(String userName, boolean notification){
        userRepository.setNotification(userName, notification);
    }

    public void updatePhone(String userName, String phone){
        userRepository.updatePhone(userName,phone);
    }

}
