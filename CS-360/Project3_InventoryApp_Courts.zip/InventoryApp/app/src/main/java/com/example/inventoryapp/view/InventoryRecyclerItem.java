package com.example.inventoryapp.view;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.inventoryapp.R;

public class InventoryRecyclerItem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_recycler_item);
    }
}