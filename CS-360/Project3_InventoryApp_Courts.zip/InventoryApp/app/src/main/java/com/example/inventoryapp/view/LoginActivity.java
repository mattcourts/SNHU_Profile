package com.example.inventoryapp.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.inventoryapp.R;
import com.example.inventoryapp.models.User;
import com.example.inventoryapp.viewModel.UserViewModel;


public class LoginActivity extends AppCompatActivity {


    private UserViewModel userViewModel;
    private EditText userNameValue;
    private EditText passwordValue;
    private Button loginButton;
    private Button registerButton;

    // enable the buttons when there is text in both fields
    TextWatcher ChangeButtonState = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            // do nothing
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // do nothing
        }

        @Override
        public void afterTextChanged(Editable s) {
            if (ValidateInputs()){
                loginButton.setEnabled(true);
                registerButton.setEnabled(true);
            } else {
                loginButton.setEnabled(false);
                registerButton.setEnabled(false);
            }
        }
    };

    // login button listener
    protected View.OnClickListener loginListener = view -> {
        User user = userViewModel.getUser(String.valueOf(userNameValue.getText()));
        if (user != null){
            if (user.getPasskey().equals(String.valueOf(passwordValue.getText()))){
                loginSuccess();
                return;
            }
        }

        loginFailure();
    };

    // register button listener
    protected View.OnClickListener registerListener = view -> {
        User newUser = new User(String.valueOf(userNameValue.getText()),String.valueOf(passwordValue.getText()));
        userViewModel.addUser(newUser);

        User user = userViewModel.getUser(String.valueOf(userNameValue.getText()));
        if (user != null){
            if (user.getPasskey().equals(String.valueOf(passwordValue.getText())) && user.getUserName().equals(String.valueOf(userNameValue.getText()))){
                LoginDialog(R.string.Login_dialog_register_success);
                passwordValue.setText("");
                return;
            }
        }

        LoginDialog(R.string.Login_dialog_register_fail);
        passwordValue.setText("");
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // tie edit text to class
        userNameValue = findViewById(R.id.login_username);
        passwordValue = findViewById(R.id.login_password);

        // tie buttons to class
        loginButton = findViewById(R.id.login_submit);
        registerButton = findViewById(R.id.login_register);

        // register listeners and watchers
        loginButton.setOnClickListener(loginListener);
        registerButton.setOnClickListener(registerListener);
        userNameValue.addTextChangedListener(ChangeButtonState);
        passwordValue.addTextChangedListener(ChangeButtonState);

        // set up model access
        userViewModel = new ViewModelProvider(this).get(UserViewModel.class);

        //set focus on username
        userNameValue.requestFocus();
    }

    // checks if both fields have content
    private boolean ValidateInputs(){
        return (!String.valueOf(passwordValue.getText()).isEmpty() && !String.valueOf(passwordValue.getText()).isEmpty());
    }

    // factory dialog generator
    private void LoginDialog(int message){
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }

    // actions when login is successful
    private void loginSuccess(){
        Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
        intent.putExtra("username",String.valueOf(userNameValue.getText()));
        startActivity(intent);

    }

    // actions when login fails
    private void loginFailure(){
        LoginDialog(R.string.Login_dialog_failure);
        passwordValue.setText("");


    }


}